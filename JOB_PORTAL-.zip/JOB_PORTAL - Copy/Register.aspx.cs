﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Register : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void SIGN_UP(object sender, EventArgs e)
    {
        string mail;
        if (firstname.Text != "" && pswrd.Text != "" && dob.Text != "" && email.Text != "" && mobile.Text != "")
        {
            con.Open();
            //     SqlCommand cmd = new SqlCommand("(select Email,Password from Admin where Password=@pswd And Email=@email) union (select Email,Password from REG where Password=@pswd And Email=@email)", con);
            SqlCommand cmd = new SqlCommand("Select * from REG where Email=@email", con);
            cmd.Parameters.AddWithValue("@email", email.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader rd = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (rd.HasRows)
            {
                rd.Read();
                Session["REGID"] = rd.GetInt32(0);
                mail = rd[7].ToString();



                if (mail!=(email.Text))
                {
                    try
                    {

                        //   SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
                        con.Open();
                        string query1 = "insert into REG(Fname,Lname,password,Mobile,Gender,Dob,Email,Country,Worke,Education,Address,IsEnabled) values(@fname,@lname,@password,@Mobile,@Gender,@Dob,@Email,@Country,@Worke,@Education,@Address,@IsEnabled)";
                        using (SqlCommand cmd1 = new SqlCommand(query1))
                        {
                            cmd1.Parameters.AddWithValue("@fname", firstname.Text);
                            cmd.Parameters.AddWithValue("@lname", lastName.Text);
                            cmd.Parameters.AddWithValue("@password", pswrd.Text);
                            cmd.Parameters.AddWithValue("@Mobile", mobile.Text);
                            cmd.Parameters.AddWithValue("@Gender", RadioButtonList1.SelectedItem.Text);
                            cmd.Parameters.AddWithValue("@Dob", dob.Text);
                            cmd.Parameters.AddWithValue("@Email", email.Text);
                            cmd.Parameters.AddWithValue("@Country", DropDownList1.SelectedItem.Text);
                            cmd.Parameters.AddWithValue("@Worke", DropDownList2.SelectedItem.Text);
                            cmd.Parameters.AddWithValue("@Education", DropDownList3.SelectedItem.Text);
                            cmd.Parameters.AddWithValue("@Address", address.Text);
                            cmd.Parameters.AddWithValue("@IsEnabled", "Y");
                            cmd.Connection = con;
                            cmd.ExecuteNonQuery();

                            ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertup()", true);

                        }
                        con.Close();

                    }
                    catch (Exception ex)
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertupp()", true);
                    }
                }
                else
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('This mail is already Exist')", true);
                }
            }
        }
        else
        {
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Please fill field')", true);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Please fill out Required(*) field')", true);
        }
    }
}