﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Home : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Features();
            Skills();
        }
    }
    public void Skills()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Newskills where IsEnabled=@enb", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            Repeater2.DataSource = dt;
            Repeater2.DataBind();
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
    public void Features()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from FeaturedEmployers where IsEnabled=@enb", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            Repeater1.DataSource = dt;
            Repeater1.DataBind();
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
    protected void Search_click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(this.srch.Text) && string.IsNullOrWhiteSpace(this.location.Text))
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Please enter Any Keyword/Location');", true);
            }
            else
            {

                if (location.Text.Length > 0 && srch.Text.Length == 0)
                {
                    Session["Location"] = location.Text;
                    Response.Redirect("~/SearchJobs.aspx");
                }
                else
                {
                    if (srch.Text.Length > 0 && location.Text.Length == 0)
                    {
                        Session["search"] = srch.Text;
                        Response.Redirect("~/SearchJobs.aspx");
                    }
                    else
                    {
                        if ((srch.Text.Length > 0) && (location.Text.Length > 0))
                        {
                            Session["search"] = srch.Text;
                            Session["Location"] = location.Text;
                            Response.Redirect("~/SearchJobs.aspx");
                        }
                        else { }
                    }
                }
            }
        }
        catch
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Login Succesfully');", true);
        }
    }
}