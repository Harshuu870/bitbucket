﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Jobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Job1();
            Job2();
        }
    }
    public void Job1()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Jobs where IsEnabled=@enb", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            repeater1.DataSource = dt;
            repeater1.DataBind();
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
    public void Job2()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Jobs where IsEnabled=@enb", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            repeater2.DataSource = dt;
            repeater2.DataBind();
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
}