﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Forgotpass : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    int RID;
    protected void Btn_Pass_click(object sender, EventArgs e)
    {
        if (Newpassword.Text.Equals(ReNewpassword.Text))
        {

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from REG where Email=@email", con);
            cmd.Parameters.AddWithValue("@email", Umail.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();
                RID = rd.GetInt32(0);
                chngpss();
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Please Enter Correct Email')", true);
            }
            con.Close();
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Please enter same password')", true);
        }
    }
    public void chngpss()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("update REG set Password=@pswrd where Email=@email", con);
        cmd.Parameters.AddWithValue("@email", Umail.Text);
        cmd.Parameters.AddWithValue("@pswrd", Newpassword.Text);
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Password Changed Succesfully');window.location='Login.aspx';", true);
        con.Close();
    }
}