﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;

public partial class Uresume : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            classload();
        }
    }

    protected void Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            string query1 = "insert into Resume(Name,Job_Name,Email,Images,IsEnabled) values(@name,@jnme,@mail,@img,@IsEnabled)";
            using (SqlCommand cmd = new SqlCommand(query1))
            {
                cmd.Parameters.AddWithValue("@name", Name.Text);
                cmd.Parameters.AddWithValue("@jnme", DropDownList1.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@mail", Email.Text);
                cmd.Parameters.AddWithValue("@IsEnabled", "Y");

                HttpPostedFile File = Img.PostedFile;
                string FileName = Path.GetFileName(File.FileName);
                Img.PostedFile.SaveAs(Server.MapPath("~/Admin/Resumes/") + FileName);
                cmd.Parameters.AddWithValue("@img", "Resumes/" + FileName);

                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                //ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertup()", true);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Resume Submitted Succesfully');window.location='Uresume.aspx';", true);


            }
            con.Close();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertup()", true);
        }
    }
    public void classload()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
        con.Open();
        using (SqlCommand cmd = new SqlCommand("select Title from Jobs where IsEnabled=@enbl", con))
        {
            cmd.CommandType = CommandType.Text;
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@enbl", "Y");
            DropDownList1.DataSource = cmd.ExecuteReader();
            DropDownList1.DataTextField = "Title";
            DropDownList1.DataValueField = "Title";
            DropDownList1.DataBind();
            con.Close();
        }
        DropDownList1.Items.Insert(0, new ListItem("-- Select Job--", "0"));
    }
}