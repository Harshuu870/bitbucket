﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Changepass : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    /*it is the code of Change Password*/
    int REGID;
    protected void btn_chng_click(object sender, EventArgs e)
    {
        if (Newpass.Text.Equals(ReNewpass.Text))
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from REG where Password=@pswrd And Email=@email", con);
            cmd.Parameters.AddWithValue("@email", Umail.Text);
            cmd.Parameters.AddWithValue("@pswrd", Upassword.Text);   /*it is id of old password*/
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();
                REGID = rd.GetInt32(0);
                updatepwd();
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Please Enter Correct old password')", true);
            }
            con.Close();
        }
        else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Please enter same password')", true);
        }
    }
    public void updatepwd()
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
        con.Open();
        SqlCommand cmd = new SqlCommand("update REG set Password=@pswrd where Email=@email And Password=@pass", con);
        cmd.Parameters.AddWithValue("@email", Umail.Text);
        cmd.Parameters.AddWithValue("@pass", Upassword.Text);
        cmd.Parameters.AddWithValue("@pswrd", Newpass.Text);
        cmd.Connection = con;
        cmd.ExecuteNonQuery();
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Password Changed Succesfully');window.location='Login.aspx';", true);
        con.Close();
    }
    /*End code of Change Password*/
}