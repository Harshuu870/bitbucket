﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Restore : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            id = Request.QueryString["id"];
            Disablefun();
        }
    }
    string id;

    public void Disablefun()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            SqlCommand cmd = new SqlCommand("update REG set IsEnabled=@enb where REGID=@sid", con);
            con.Open();
            {

                cmd.Parameters.AddWithValue("@sid", id);
                cmd.Parameters.AddWithValue("@enb", "Y");
                cmd.ExecuteNonQuery();

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Blocked Successfully');window.location='Regdata.aspx';", true);

            }
            con.Close();
        }
        catch
        {
        }
    }
}