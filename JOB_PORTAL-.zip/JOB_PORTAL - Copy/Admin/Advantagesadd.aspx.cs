﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Advantagesadd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Addadd(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            string query1 = "insert into Advantages(Add_no,Heading,Para1,Para2,IsEnabled) values(@name,@post,@work,@work2,@enb)";
            using (SqlCommand cmd = new SqlCommand(query1))
            {
                cmd.Parameters.AddWithValue("@name", no.Text);
                cmd.Parameters.AddWithValue("@post", head.Text);
                cmd.Parameters.AddWithValue("@work", para1.Text);
                cmd.Parameters.AddWithValue("@work2", para2.Text);
                cmd.Parameters.AddWithValue("@enb", "Y");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Added Succesfully');window.location='AdvatagesAdd.aspx';", true);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
}