﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddFeatures : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Sub_Click(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            string query1 = "insert into FeaturedEmployers(Pic,IsEnabled) values(@img,@enb)";
            using (SqlCommand cmd = new SqlCommand(query1))
            {
                cmd.Parameters.AddWithValue("@enb", "Y");
                HttpPostedFile File = img.PostedFile;
                string FileName = Path.GetFileName(File.FileName);
                img.PostedFile.SaveAs(Server.MapPath("~/Admin/FeaturedImages/") + FileName);
                cmd.Parameters.AddWithValue("@img", "FeaturedImages/" + FileName);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Added Succesfully');window.location='OurteamAdd.aspx';", true);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
}