﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_ResSerAdd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblsd.Text = Request.QueryString["id"];
            content.Text = Request.QueryString["Content"];
            para.Text = Request.QueryString["Para"];
        }
    }
    protected void Sub_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
        con.Open();
        string query1 = "update Resumeservices set Content=@Content,Para=@Para where RESID=@sid";
        using (SqlCommand cmd = new SqlCommand(query1))
        {
            cmd.Parameters.AddWithValue("@Content", content.Text);
            cmd.Parameters.AddWithValue("@sid", lblsd.Text);
            cmd.Parameters.AddWithValue("@Para", para.Text);
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("~/Admin/ResSer.aspx");
        }
    }
}