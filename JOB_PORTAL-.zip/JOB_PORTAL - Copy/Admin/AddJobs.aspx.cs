﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddJobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Add(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            string query1 = "insert into Jobs(Date,Month,Title,Location,Para1,Para2,Img,IsEnabled) values(@dte,@mnth,@titl,@loc,@para1,@para2,@img,@enb)";
            using (SqlCommand cmd = new SqlCommand(query1))
            {
                cmd.Parameters.AddWithValue("@dte", dte.Text);
                cmd.Parameters.AddWithValue("@mnth", mnth.Text);
                cmd.Parameters.AddWithValue("@titl", jobnme.Text);
                cmd.Parameters.AddWithValue("@loc", loc.Text);
                cmd.Parameters.AddWithValue("@para1", para1.Text);
                cmd.Parameters.AddWithValue("@para2", para2.Text);
                cmd.Parameters.AddWithValue("@enb", "Y");
                HttpPostedFile File = img.PostedFile;
                string FileName = Path.GetFileName(File.FileName);
                img.PostedFile.SaveAs(Server.MapPath("~/Admin/JobImg/") + FileName);
                cmd.Parameters.AddWithValue("@img", "JobImg/" + FileName);
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Added Succesfully');window.location='JobsAdd.aspx';", true);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
}