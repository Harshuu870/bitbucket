﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AddAddress : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Add(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            string query1 = "insert into ContactAdd(Address,Freephone,Telephone,FAX,Email,IsEnabled) values(@dte,@mnth,@titl,@loc,@para1,@enb)";
            using (SqlCommand cmd = new SqlCommand(query1))
            {
                cmd.Parameters.AddWithValue("@dte", dte.Text);
                cmd.Parameters.AddWithValue("@mnth", mnth.Text);
                cmd.Parameters.AddWithValue("@titl", jobnme.Text);
                cmd.Parameters.AddWithValue("@loc", loc.Text);
                cmd.Parameters.AddWithValue("@para1", para1.Text);
                cmd.Parameters.AddWithValue("@enb", "Y");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();
                con.Close();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Added Succesfully');window.location='ContactAdd.aspx';", true);
            }
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
}