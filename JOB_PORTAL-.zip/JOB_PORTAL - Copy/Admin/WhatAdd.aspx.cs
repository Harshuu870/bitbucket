﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_WhatAdd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //string id=Request.QueryString["SID"]; 
            lblsd.Text = Request.QueryString["Img"];
            content.Text = Request.QueryString["Head_para"];
            para.Text = Request.QueryString["Para"];
        }
    }
    protected void Sub_Click(object sender, EventArgs e)
    {
        string Imgpath = Image1.ImageUrl;
        string ext = Path.GetExtension(FileUpload1.FileName);
        FileInfo x = new FileInfo(Server.MapPath(Imgpath));
        try
        {
            x.Delete();
        }
        catch { }
        Imgpath = "ServiceImg/" + Guid.NewGuid()+ext;
        FileUpload1.SaveAs(Server.MapPath(Imgpath));
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
        con.Open();
        string query1 = "update Services set Img=@Img,Head_para=@Hpara,Para=@Para where SID=@sid";
        using (SqlCommand cmd = new SqlCommand(query1))
        {
            cmd.Parameters.AddWithValue("@Hpara", content.Text);
            cmd.Parameters.AddWithValue("@sid",Request.QueryString["SID"]);
            cmd.Parameters.AddWithValue("@Para", para.Text);
           // HttpPostedFile File = FileUpload1.PostedFile;
           // string FileName = Path.GetFileName(File.FileName);
            //FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Admin/ServiceImg/") + FileName);
            cmd.Parameters.AddWithValue("@Img",Imgpath);
            
            cmd.Connection = con;
            cmd.ExecuteNonQuery();
            con.Close();
            Response.Redirect("~/Admin/What.aspx");
        }
    }
}