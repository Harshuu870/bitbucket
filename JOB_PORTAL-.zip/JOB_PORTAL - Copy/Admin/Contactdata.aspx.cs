﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Admin_Contactdata : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Contactload();
        }
    }
    public void Contactload()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Contact where IsEnabled=@enb", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            grduserTable.DataSource = dt;
            grduserTable.DataBind();
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
    protected void deletebutton_Click(object sender, EventArgs e)
    {
        Button del = (Button)sender;
        string id = del.CommandArgument;

        string con_str = ConfigurationManager.ConnectionStrings["Constr"].ConnectionString;
        SqlConnection con = new SqlConnection(con_str);
        SqlCommand cmd = new SqlCommand();
        cmd.Connection = con;
        cmd.CommandText = "delete from Contact where CID=" + id + "";

        con.Open();
        int flag = cmd.ExecuteNonQuery();
        con.Close();

        if (flag > 0)
        {
            Response.Write("<script>alert('Deleted Succesfully.')</script>");
        }
        else
        {
            Response.Write("<script>alert('Picture Not Deleted.')</script>");
        }

        Contactload();
    }
}