﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    string pswd;
    string email;
      protected void Login_click(object sender, EventArgs e)
      {

       //   SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
          con.Open();
        //     SqlCommand cmd = new SqlCommand("(select Email,Password from Admin where Password=@pswd And Email=@email) union (select Email,Password from REG where Password=@pswd And Email=@email)", con);
        SqlCommand cmd = new SqlCommand("Select * from REG where Email=@email And password=@pswd And IsEnabled=@enb", con);
        cmd.Parameters.AddWithValue("@email", Umail.Text);
          cmd.Parameters.AddWithValue("@pswd", Upassword.Text);
        cmd.Parameters.AddWithValue("@enb", 'Y');
        SqlDataAdapter da = new SqlDataAdapter(cmd);
          SqlDataReader rd = cmd.ExecuteReader();
        DataTable dt = new DataTable();
        if (rd.HasRows)
        {
            rd.Read();
            Session["REGID"] = rd.GetInt32(0);
            pswd = rd[3].ToString();
            email = rd[7].ToString();
            


            if (email.Equals(Umail.Text) && pswd.Equals(Upassword.Text))
            {
                HttpCookie obj = new HttpCookie("userinfo");
                //obj["email"] = dt.Rows[0]["email"].ToString();
                obj.Expires = DateTime.Now.AddDays(2);
                Response.Cookies.Add(obj);
                Session["pswd"] = pswd;
                Session["email"] = email;
                 ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Login Succesfully');window.location='../Ujobs.aspx';", true);
               // Response.Redirect("Ujobs.aspx");
            }
            else { }
        }
        
        else
        {
            con.Close();
            con.Open();
            SqlCommand cmd1 = new SqlCommand("Select * from Admin where Email=@email And Password=@pswd", con);
            cmd1.Parameters.AddWithValue("@email", Umail.Text);
            cmd1.Parameters.AddWithValue("@pswd", Upassword.Text);
       
            SqlDataAdapter da1 = new SqlDataAdapter(cmd1);
            SqlDataReader rd1 = cmd1.ExecuteReader();
            DataTable dts = new DataTable();
            if (rd1.HasRows)
            {
                rd1.Read();
                Session["AID"] = rd1.GetInt32(0);
                email = rd1[1].ToString();
                pswd = rd1[2].ToString();


                if (email.Equals(Umail.Text) && pswd.Equals(Upassword.Text))
                {
                    HttpCookie obj = new HttpCookie("admininfo");
                   // obj["Email"] = dt.Rows[1]["Email"].ToString();
                    obj.Expires = DateTime.Now.AddDays(10);
                    Response.Cookies.Add(obj);
                    Session["pswd"] = pswd;
                    Session["email"] = email;
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Login Succesfully');window.location='Admin/Default.aspx';", true);
                }
            }
            
            else
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Please Enter Correct Information')", true);
        }
            con.Close();
        }
          
      }
}