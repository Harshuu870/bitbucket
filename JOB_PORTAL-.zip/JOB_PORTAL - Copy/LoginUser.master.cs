﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class LoginUser : System.Web.UI.MasterPage
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Cookies["userinfo"] == null)
        {
            Response.Redirect("Login.aspx");
        }
    }
    //Searching Code-----
    protected void Search_click(object sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(this.srch.Text) && string.IsNullOrWhiteSpace(this.location.Text))
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Please enter Any Keyword/Location');", true);
            }
            else
            {

                if (location.Text.Length > 0 && srch.Text.Length == 0)
                {
                    Session["Location"] = location.Text;
                    Response.Redirect("~/Usearchjobs.aspx");
                }
                else
                {
                    if (srch.Text.Length > 0 && location.Text.Length == 0)
                    {
                        Session["search"] = srch.Text;
                        Response.Redirect("~/Usearchjobs.aspx");
                    }
                    else
                    {
                        if ((srch.Text.Length > 0) && (location.Text.Length > 0))
                        {
                            Session["search"] = srch.Text;
                            Session["Location"] = location.Text;
                            Response.Redirect("~/Usearchjobs.aspx");
                        }
                        else { }
                    }
                }
            }
        }
        catch
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error');", true);
        }
    }
}