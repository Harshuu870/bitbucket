﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Load();
    }
    protected void Cont(object sender, EventArgs e)
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            string query1 = "insert into Contact(Name,Email,Phone,Message,IsEnabled) values(@name,@mail,@phone,@Msg,@IsEnabled)";
            using (SqlCommand cmd = new SqlCommand(query1))
            {
                cmd.Parameters.AddWithValue("@name", Name.Text);
                cmd.Parameters.AddWithValue("@mail", Email.Text);
                cmd.Parameters.AddWithValue("@phone", Phone.Text);
                cmd.Parameters.AddWithValue("@Msg", Msg.Text);
                cmd.Parameters.AddWithValue("@IsEnabled", "Y");
                cmd.Connection = con;
                cmd.ExecuteNonQuery();

                ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertup()", true);
            }
            con.Close();
        }
        catch (Exception ex)
        {
            ClientScript.RegisterStartupScript(this.GetType(), "randomtext", "alertupp()", true);
        }
    }
    public void Load()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from ContactAdd where IsEnabled=@enb", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            Repeater1.DataSource = dt;
            Repeater1.DataBind();
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
}