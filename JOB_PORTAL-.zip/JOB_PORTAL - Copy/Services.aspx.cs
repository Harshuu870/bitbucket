﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Services : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LOAD1();
        LOAD2();
        LOAD3();
        LOAD4();
        LOAD5();
        LOAD6();
        string img;
        string Head;
        string Para;
        if (!IsPostBack)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            using (SqlCommand cmd = new SqlCommand("select * from Services", con))
            {
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                SqlDataReader rd = cmd.ExecuteReader();
                if (rd.HasRows)
                {
                    rd.Read();
                    Session["SID"] = rd.GetInt32(0);
                    img = rd[1].ToString();
                    Head = rd[2].ToString();
                    Para = rd[3].ToString();
                    Session["img"] = img;
                    Session["head"] = Head;
                    Session["para"] = Para;

                }
            }
            con.Close();
        }
    }
    public void LOAD1()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select top 1 * from Resumeservices where IsEnabled=@enb order by RESID desc", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();

                Label1.Text = rd[1].ToString();
                Label2.Text = rd[2].ToString();
            }
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
    public void LOAD2()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select top 1 * from (select top 2 * from Resumeservices where IsEnabled=@enb order by RESID desc) x  order by RESID ", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();

                Label3.Text = rd[1].ToString();
                Label4.Text = rd[2].ToString();
            }
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
    public void LOAD3()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select top 1 * from (select top 3 * from Resumeservices where IsEnabled=@enb order by RESID desc) x  order by RESID ", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();

                Label5.Text = rd[1].ToString();
                Label6.Text = rd[2].ToString();
            }
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }

    public void LOAD4()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select top 1 * from (select top 4 * from Resumeservices where IsEnabled=@enb order by RESID desc) x  order by RESID ", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();

                Label7.Text = rd[1].ToString();
                Label8.Text = rd[2].ToString();
            }
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }

    public void LOAD5()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select top 1 * from (select top 5 * from Resumeservices where IsEnabled=@enb order by RESID desc) x  order by RESID ", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();

                Label9.Text = rd[1].ToString();
                Label10.Text = rd[2].ToString();
            }
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }

    public void LOAD6()
    {
        try
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("select top 1 * from (select top 6 * from Resumeservices where IsEnabled=@enb order by RESID desc) x  order by RESID ", con);
            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlDataReader rd = cmd.ExecuteReader();
            if (rd.HasRows)
            {
                rd.Read();

                Label11.Text = rd[1].ToString();
                Label12.Text = rd[2].ToString();
            }
            con.Close();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertmsg", "alert('Error')", true);
        }
    }
}