﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SearchJobs : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Search_click();
            
        }
    }
    public void Search_click()
    {

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
        
        if (Session["Location"]==null)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Jobs where Title LIKE '%" + Session["search"] + "%' AND IsEnabled=@enb", con);

            cmd.Parameters.AddWithValue("@enb", "Y");
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            da.Fill(ds);
            dt = ds.Tables[0];
            repeater1.DataSource = dt;
            repeater1.DataBind();
            repeater2.DataSource = dt;
            repeater2.DataBind();
            con.Close();
            Session.Clear();
        }
        else
        {
            if (Session["search"] == null)
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("select * from Jobs where Location LIKE '%" + Session["Location"] + "%' AND IsEnabled=@enb", con);

                cmd.Parameters.AddWithValue("@enb", "Y");
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                da.Fill(ds);
                dt = ds.Tables[0];
                repeater1.DataSource = dt;
                repeater1.DataBind();
                repeater2.DataSource = dt;
                repeater2.DataBind();
                con.Close();
                Session.Clear();
            }
            else
            {
                if (Session["search"] != null && Session["Location"] != null)
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("(select * from Jobs where Title LIKE '%" + Session["search"] + "%') Union (select * from Jobs where Location LIKE '%" + Session["Location"] + "%')", con);
                  //  cmd.Parameters.AddWithValue("@enb", "Y");
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    DataTable dt = new DataTable();
                    da.Fill(ds);
                    dt = ds.Tables[0];
                    repeater1.DataSource = dt;
                    repeater1.DataBind();
                    repeater2.DataSource = dt;
                    repeater2.DataBind();
                    con.Close();
                    Session.Clear();
                }
                else { }
            }
        }
    }
}